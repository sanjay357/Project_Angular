﻿using Couchbase;
using Couchbase.Core.Exceptions;
using Microsoft.Extensions.Logging;
using Polly;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Webapi_project_1.Interface;
using Webapi_project_1.Model;

namespace Webapi_project_1.Services
{
    public class EmployeeCouchbaseService : IEmployeeCouchbaseService
    {
        private readonly ILogger<EmployeeCouchbaseService> logger;

        public EmployeeCouchbaseService(ILogger<EmployeeCouchbaseService> logger)
        {
            this.logger = logger;
        }
        public async Task<Employees> DeleteEmployeById( int id)
        {
            try
            {
                var cluster = await Initialize();
           
                var bucket = await cluster.BucketAsync("Employees");


                var collection = bucket.DefaultCollection();

                await collection.RemoveAsync(id.ToString());
                return null;
            }
            catch (BucketNotFoundException)
            {
                logger.LogError("Bucket not found");
                throw new BucketNotFoundException();
            }

        }

        public async Task<Employees> GetEmployeById( int id)
        {
            var cluster = await Initialize();
            Employees employee = new Employees();
            var queryResult = await cluster.QueryAsync<Employees>("SELECT username,name,email,age,location,srccs,phoneNumber,salary,skill,managerName,address,id FROM Employees where id=" + id, new Couchbase.Query.QueryOptions());



            await foreach (var row in queryResult)
            {
                employee = row;
            }
            if (employee == null)
            {
                logger.LogWarning($"Id with {id} not available in the bucket");
            }

            return employee;
        }



        public async Task<EmployeeCollection> GetEmployees(ICluster cluster, Paging paging)
        {
            try
            {
                var queryResult = await cluster.QueryAsync<Employees>($"SELECT username,name,email,age,location,srccs,phoneNumber,salary,skill,managerName,address,id FROM Employees OFFSET {paging.start} LIMIT {paging.end}", new Couchbase.Query.QueryOptions());

                List<Employees> empList = new List<Employees>();

                await foreach (var row in queryResult)
                {
                    empList.Add(row);
                }
                EmployeeCollection emp = new EmployeeCollection();
                int count = await GetEmployeescount(cluster);
                emp.employees = empList;
                emp.employeeCount = count;
                return emp;


            }
            catch (IndexFailureException)
            {
                logger.LogError("Bucket not found");
                throw;
            }


        }

        public async Task<ICluster> Initialize()
        {
            try
            {
                var policy = Policy.Handle<Exception>()
                   .WaitAndRetryAsync(2, count => TimeSpan.FromSeconds(3));
                await policy.ExecuteAsync(async () =>
                {

                    logger.LogInformation("Retrying to connect couchbase for EmployeeController...");
                    await Retry();
                });
                return await Retry();
            }

            catch (AuthenticationFailureException)
            {
                logger.LogError("Authentication error");
                throw;
            }

        }
        public async Task<ICluster> Retry()
        {
            var cluster = await Cluster.ConnectAsync("couchbase://localhost", "adm", "sanjay753");
            var bucket = await cluster.BucketAsync("Employees");
            var collection = bucket.DefaultCollection();
            return cluster;
        }

        public async Task<Employees> PutEmployeById( int id, Employees value)
        {
            var cluster = await Initialize();
            var bucket = await cluster.BucketAsync("Employees");
            var collection = bucket.DefaultCollection();
            var collectiondata = await collection.UpsertAsync(id.ToString(), value);

            if (collectiondata == null)
            {
                logger.LogError("Error in update");
            }
            return value;

        }
        //create
        public async Task<Employees> PostEmploye(Employees value)
        {
            if(value.id==0)
            {
                throw new ArgumentNullException("There is no id value");
            }
            var cluster = await Initialize();

            var bucket = await cluster.BucketAsync("Employees");
            var collection = bucket.DefaultCollection();
            int idvalue = value.id;
            var collectiondataa = await collection.InsertAsync(idvalue.ToString(), value);
            if (collectiondataa == null)
            {
                logger.LogError("Error in creating");
            }

            return null;
        }

        public async Task<int> GetEmployeescount(ICluster cluster)
        {
            List<Employees> employees = new List<Employees>();
            var queryResults = await cluster.QueryAsync<Employees>("SELECT username,name,email,age,location,srccs,phoneNumber,salary,skill,managerName,address,id FROM Employees ", new Couchbase.Query.QueryOptions());



            await foreach (var row in queryResults)
            {
                employees.Add(row);
            }
            int count=employees.Count;


            return count;
        }
        public async Task<LoginDetails> PostLogin( LoginDetails form)
        {
            try
            {
                if (form.id == 0)
                {
                    logger.LogInformation("id field is empty");
                    throw new ArgumentNullException("id field is empty");
                }
                var cluster = await Initialize();
                var bucket = await cluster.BucketAsync("LoginDetails");
                var collection = bucket.DefaultCollection();
                var idvalue = form.id;
                await collection.InsertAsync(idvalue.ToString(), form);


                return form;

            }

            catch (IndexFailureException)
            {
                logger.LogError("Bucket not found for LoginController");
                throw;
            }

        }
    }
}
    

