export class UserInfo {
    username: string;
    pwd: string;
    photo:string;
    id:any;
    department:string;
    logintype:string;
}
