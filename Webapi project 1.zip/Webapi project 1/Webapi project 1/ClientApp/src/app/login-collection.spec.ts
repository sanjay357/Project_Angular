import { LoginCollection } from './login-collection';

describe('LoginCollection', () => {
  it('should create an instance', () => {
    expect(new LoginCollection()).toBeTruthy();
  });
});
