﻿using Couchbase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Webapi_project_1.Model;

namespace Webapi_project_1.Interface
{
    public interface IEmployeeCouchbaseService
{
        Task<ICluster> Initialize();
        Task<EmployeeCollection> GetEmployees(ICluster cluster,Paging paging);
        Task<Employees> GetEmployeById( int id);
        Task<Employees> DeleteEmployeById( int id);
        Task<Employees> PostEmploye(Employees value );
        Task<Employees> PutEmployeById( int id,Employees value);
        Task<int> GetEmployeescount(ICluster cluster);
        Task<LoginDetails> PostLogin( LoginDetails form);

    }
}
